export { onRenderBody } from "./internal/gatsby/on-render-body";
export { wrapRootElement } from "./internal/gatsby/wrap-root-element";
