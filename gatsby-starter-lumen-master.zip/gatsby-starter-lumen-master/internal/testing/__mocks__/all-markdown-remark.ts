import edges from "./edges";
import group from "./group";

export default { group, edges };
