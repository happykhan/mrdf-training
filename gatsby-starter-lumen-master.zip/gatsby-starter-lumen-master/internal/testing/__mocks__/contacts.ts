export default {
  rss: "#",
  email: "#",
  github: "#",
  twitter: "#",
  telegram: "#",
};
