export default [
  {
    fieldValue: "typography",
    totalCount: 1,
  },
  {
    fieldValue: "design inspiration",
    totalCount: 1,
  },
];
