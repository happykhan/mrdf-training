export default [
  { label: "Articles", path: "/" },
  { label: "About Me", path: "/pages/about" },
  { label: "Contact Me", path: "/pages/contacts" },
];
