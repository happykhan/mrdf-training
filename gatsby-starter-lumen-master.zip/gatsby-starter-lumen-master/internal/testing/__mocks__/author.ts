import contacts from "./contacts";

export default {
  photo: "/photo.jpg",
  bio: "Pellentesque odio nisi, euismod in, pharetra a, ultricies in, diam. Sed arcu.",
  name: "John Doe",
  contacts,
};
