const decrement = (n: number): number => n - 1;

export default decrement;
