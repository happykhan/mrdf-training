const concat = (...args: string[]): string => args.join("");

export default concat;
