interface Dictionary<T> {
  [key: string]: T;
}

export default Dictionary;
