interface Fields {
  slug: string;
  categorySlug: string;
  tagSlugs?: Array<string>;
}

export default Fields;
