import Node from "./node";

interface Edge {
  node: Node;
}

export default Edge;
