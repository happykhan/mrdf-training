export { default as Copyright } from "./Copyright";
