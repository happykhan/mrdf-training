export { default as Post } from "./Post";
